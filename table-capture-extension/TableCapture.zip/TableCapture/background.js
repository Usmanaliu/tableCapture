chrome.runtime.onInstalled.addListener(() => {
    console.log("Table Capture installed.");
});


chrome.runtime.onMessage.addListener(
    async (message, sender) => {

        if (
            message.action === "captureProgress" ||
            message.action === "captureComplete"
        ) {

            console.log(
                "Capture message:",
                message
            );
        }
    }
);