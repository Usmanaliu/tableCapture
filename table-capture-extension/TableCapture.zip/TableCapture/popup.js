let tables = [];
let selectedTable = null;
let capturedRows = null;

let statusTimer = null;


// ======================================================
// GET CURRENT TAB
// ======================================================

async function getCurrentTab() {

    const tabs = await chrome.tabs.query({
        active: true,
        currentWindow: true
    });

    return tabs[0];
}


// ======================================================
// DETECT TABLES
// ======================================================

async function detectTables() {

    const tab = await getCurrentTab();

    chrome.tabs.sendMessage(
        tab.id,
        {
            action: "getTables"
        },
        response => {

            if (chrome.runtime.lastError) {

                document.getElementById(
                    "info"
                ).innerText =
                    "❌ Unable to access this page.";

                return;
            }

            if (!response) {

                document.getElementById(
                    "info"
                ).innerText =
                    "❌ No response from webpage.";

                return;
            }

            tables = response.tables || [];

            const select =
                document.getElementById(
                    "tableSelect"
                );

            select.innerHTML =
                '<option value="">Select a table</option>';


            tables.forEach(
                (table, index) => {

                    const option =
                        document.createElement(
                            "option"
                        );

                    option.value = index;

                    option.textContent =
                        `Table ${index + 1} — ${table.rowCount} rows × ${table.columnCount} columns`;

                    select.appendChild(
                        option
                    );
                }
            );


            document.getElementById(
                "info"
            ).innerText =
                `${tables.length} table(s) detected.`;
        }
    );
}


// ======================================================
// DETECT BUTTON
// ======================================================

document.getElementById(
    "scanBtn"
).addEventListener(
    "click",
    detectTables
);


// ======================================================
// SELECT TABLE
// ======================================================

document.getElementById(
    "tableSelect"
).addEventListener(
    "change",
    function () {

        if (this.value === "") {

            selectedTable = null;

            document.getElementById(
                "info"
            ).innerText =
                "No table selected.";

            return;
        }


        selectedTable =
            tables[
                Number(this.value)
            ];


        capturedRows = null;


        document.getElementById(
            "info"
        ).innerText =
            `${selectedTable.rowCount} rows × ${selectedTable.columnCount} columns`;
    }
);


// ======================================================
// CAPTURE FULL TABLE
// ======================================================

async function startCapture() {

    if (!selectedTable) {

        alert(
            "Please select a table first."
        );

        return;
    }


    const tab =
        await getCurrentTab();


    capturedRows = null;


    const info =
        document.getElementById(
            "info"
        );


    const captureButton =
        document.getElementById(
            "captureBtn"
        );


    captureButton.disabled = true;

    captureButton.innerText =
        "⏳ Capturing...";


    info.innerText =
        "⏳ Starting full table capture...";


    // Clear previous capture

    await chrome.storage.local.set({

        captureStatus: "starting",

        captureRows: [],

        capturePage: 0,

        captureTotal: 0,

        captureError: ""

    });


    chrome.tabs.sendMessage(
        tab.id,
        {
            action: "startCapture",

            tableIndex:
                selectedTable.index

        },
        response => {

            if (chrome.runtime.lastError) {

                captureButton.disabled = false;

                captureButton.innerText =
                    "🚀 Capture Full Table";


                info.innerText =
                    "❌ Could not start capture.";

                return;
            }


            monitorCapture();
        }
    );
}


// ======================================================
// MONITOR CAPTURE
// ======================================================

function monitorCapture() {

    if (statusTimer) {

        clearInterval(
            statusTimer
        );
    }


    statusTimer =
        setInterval(
            async () => {

                const data =
                    await chrome.storage.local.get([
                        "captureStatus",
                        "captureRows",
                        "capturePage",
                        "captureTotal",
                        "captureError"
                    ]);


                const info =
                    document.getElementById(
                        "info"
                    );


                const captureButton =
                    document.getElementById(
                        "captureBtn"
                    );


                // -------------------------------
                // CAPTURING
                // -------------------------------

                if (
                    data.captureStatus ===
                    "capturing"
                ) {

                    info.innerText =
                        `⏳ Page ${data.capturePage} — ${data.captureTotal} records captured`;
                }


                // -------------------------------
                // COMPLETE
                // -------------------------------

                if (
                    data.captureStatus ===
                    "complete"
                ) {

                    clearInterval(
                        statusTimer
                    );


                    capturedRows =
                        data.captureRows || [];


                    captureButton.disabled =
                        false;


                    captureButton.innerText =
                        "🚀 Capture Full Table";


                    info.innerText =
                        `✅ COMPLETE — ${capturedRows.length} records captured`;


                    console.log(
                        "FULL TABLE:",
                        capturedRows
                    );
                }


                // -------------------------------
                // ERROR
                // -------------------------------

                if (
                    data.captureStatus ===
                    "error"
                ) {

                    clearInterval(
                        statusTimer
                    );


                    captureButton.disabled =
                        false;


                    captureButton.innerText =
                        "🚀 Capture Full Table";


                    info.innerText =
                        `❌ ${data.captureError}`;
                }

            },
            500
        );
}


// ======================================================
// CAPTURE BUTTON
// ======================================================

document.getElementById(
    "captureBtn"
).addEventListener(
    "click",
    startCapture
);


// ======================================================
// COPY
// ======================================================

document.getElementById(
    "copyBtn"
).addEventListener(
    "click",
    async () => {

        if (
            !capturedRows ||
            capturedRows.length === 0
        ) {

            alert(
                "Please click 'Capture Full Table' first."
            );

            return;
        }


        const text =
            capturedRows
                .map(row =>
                    row.join("\t")
                )
                .join("\n");


        await navigator.clipboard.writeText(
            text
        );


        alert(
            `✅ Copied ${capturedRows.length} records!`
        );
    }
);


// ======================================================
// CSV
// ======================================================

document.getElementById(
    "csvBtn"
).addEventListener(
    "click",
    async () => {

        if (
            !capturedRows ||
            capturedRows.length === 0
        ) {

            alert(
                "Please click 'Capture Full Table' first."
            );

            return;
        }


        const csv =
            capturedRows
                .map(row =>
                    row.map(cell =>
                        `"${String(cell)
                            .replace(/"/g, '""')}"`
                    ).join(",")
                )
                .join("\n");


        downloadFile(
            csv,
            "table-full.csv",
            "text/csv"
        );
    }
);


// ======================================================
// JSON
// ======================================================

document.getElementById(
    "jsonBtn"
).addEventListener(
    "click",
    async () => {

        if (
            !capturedRows ||
            capturedRows.length === 0
        ) {

            alert(
                "Please click 'Capture Full Table' first."
            );

            return;
        }


        const json =
            JSON.stringify(
                capturedRows,
                null,
                2
            );


        downloadFile(
            json,
            "table-full.json",
            "application/json"
        );
    }
);


// ======================================================
// DOWNLOAD
// ======================================================

function downloadFile(
    content,
    filename,
    type
) {

    const blob =
        new Blob(
            [content],
            {
                type: type
            }
        );


    const url =
        URL.createObjectURL(
            blob
        );


    const a =
        document.createElement(
            "a"
        );


    a.href = url;

    a.download = filename;


    document.body.appendChild(
        a
    );


    a.click();


    a.remove();


    URL.revokeObjectURL(
        url
    );
}